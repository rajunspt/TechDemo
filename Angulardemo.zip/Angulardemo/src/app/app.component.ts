import { Component, } from '@angular/core';
import { Router,NavigationEnd } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = '';
  public currentUrl = "";
  constructor(private router: Router) {     
    router.events.subscribe(e => {
      if (e instanceof NavigationEnd) {
        this.currentUrl = e.url;       
        if(this.currentUrl === "/"){
          this.currentUrl = '/login'
        }
        if(this.currentUrl === "/dashboard"){
          this.title = 'Dashboard'
        }
        if(this.currentUrl === "/page1"){
          this.title = 'Page1'
        }
        if(this.currentUrl === "/page2"){
          this.title = 'Page2'
        }
      }
    });
  }
}
