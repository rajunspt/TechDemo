import React from 'react'

const Country = () => {
  return (
   <h1> country page</h1>
  )
}

export default Country
