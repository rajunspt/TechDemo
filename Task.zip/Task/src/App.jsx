import React, { Children } from "react";
import { AppLayout } from "./components/Layout/AppLayout";


const App = () => {
  return <AppLayout />;
};

export default App;
