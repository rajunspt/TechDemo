 import Headers from "../UI/Headers"
 import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Footers from "../UI/Footers"
import Home from "../../Pages/Home"
import About from "../../Pages/About";
import Contact from "../../Pages/Contact";
import Country from "../../Pages/Country";

export const AppLayout = () => { 

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
       <Headers/>
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>       
      </div>
     
    </Router>
  );
}


