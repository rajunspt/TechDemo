import React from 'react';
import { NavLink } from 'react-router-dom';

const Navbar = () => {
  const links = [
    { to: '/', label: 'Home' },
    { to: '/about', label: 'About' },
    { to: '/projects', label: 'Projects' },
    { to: '/resources', label: 'Resources' },
    { to: '/contact', label: 'Contact' },
  ];

  return (
    <div className="flex md:flex-row flex-col md:items-center md:gap-8">
      {links.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          className={({ isActive }) =>
            `text-base font-medium transition-all duration-200 relative
            ${isActive ? 'text-indigo-600' : 'text-gray-700 hover:text-indigo-600'}
            after:content-[''] after:absolute after:w-full after:h-0.5 
            after:bg-indigo-600 after:left-0 after:-bottom-1 
            after:rounded-full after:origin-left
            after:transition-transform after:duration-300
            after:scale-x-0 hover:after:scale-x-100
            ${isActive ? 'after:scale-x-100' : ''}`
          }
        >
          {link.label}
        </NavLink>
      ))}
    </div>
  );
};

export default Navbar;