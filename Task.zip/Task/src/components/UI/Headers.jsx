import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Rocket } from "lucide-react";
import Navbar from "../UI/Navbar";

const Headers = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center space-x-3 group transition-transform duration-200 hover:scale-105"
          >
            <div className="relative">
              <Rocket className="h-9 w-9 text-indigo-600 transform group-hover:rotate-12 transition-transform duration-300" />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-indigo-200 rounded-full opacity-50 animate-pulse" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-indigo-800 bg-clip-text text-transparent">
                Test App
              </span>
              <span className="text-xs text-gray-500 -mt-1">
                Reach for small tasks
              </span>
            </div>
          </Link>

          {/* Navigation */}
          <div className="hidden md:block">
            <Navbar />
          </div>

          {/* Mobile Toggle Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-indigo-600 hover:bg-gray-100 focus:outline-none"
          >
            {isOpen ? (
              <X className="block h-6 w-6" />
            ) : (
              <Menu className="block h-6 w-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Navbar />
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Headers;
